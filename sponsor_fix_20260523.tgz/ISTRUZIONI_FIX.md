# Fix sessione 2026-05-23 — Sponsor Manager

## Cosa contiene questo pacchetto

    portal/views/cart.py                              <- FILE CORRETTO (sostituisce l'esistente)
    portal/management/commands/fix_snapshot_json.py   <- NUOVO comando di pulizia dati
    cart_modifiche.diff                               <- riepilogo leggibile delle modifiche

## Bug risolti

### 1. JSON snapshot corrotto (PRIORITARIO) — RISOLTO
Causa reale: in `portal/views/cart.py` (riga ~233) il carrello passava
`service.name` e `service.description`, cioe' i dizionari grezzi delle
traduzioni ({'en': ..., 'it': ...}), dentro un CharField. Django li
convertiva in stringa con gli apici singoli -> "{'en': '...'}".
NON era un bug di ContractLine.save() come ipotizzato.
Fix: ora usa `service.translated('name')` / `service.translated('description')`.

### 2. Metodo inesistente recalc_totals() — RISOLTO
cart.py chiamava `recalc_totals()` in 6 punti, ma sui modelli i metodi
si chiamano `calculate_totals()` (ContractLine) e `recalculate_totals()`
(Contract). Avrebbe sollevato AttributeError. Corrette tutte e 6,
rimosse le chiamate ridondanti (save()/delete() ricalcolano gia' da soli).

## Come applicare (in WSL, dentro ~/progetti/sponsor_manager)

1. Sostituisci il file del carrello:
       cp .../portal/views/cart.py portal/views/cart.py

2. Aggiungi il nuovo comando:
       cp .../portal/management/commands/fix_snapshot_json.py \
          portal/management/commands/fix_snapshot_json.py

3. Pulisci i dati gia' sporcati nel DB (prima a vuoto, poi davvero):
       python manage.py fix_snapshot_json --dry-run
       python manage.py fix_snapshot_json

4. Verifica: aggiungi un articolo al carrello con lo sponsor di test
   "gloriamed". L'errore di aggiunta dovrebbe essere sparito e il nome
   servizio comparire pulito (es. "Faretto LED", non "{'it': ...}").

## Ancora da fare (dalle note di progetto)

- DB disallineato dal codice (colonne fantasma es. payment_plan_mode):
  riallineare ricreando il DB dalle migrazioni + ri-seed dati test.
- Migrazione wishlist pendente: generare
  portal/migrations/0002_alter_wishlist_user.py
